<!DOCTYPE html>
<html>
<head>
    <title>View Rooms</title>
    <style>
        table {
            border-collapse: collapse;
            width: 70%;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ccc;
        }
        th {
            background-color: #f2f2f2;
        }
        a {
            text-decoration: none;
            color: red;
        }
    </style>
</head>
<body>
    <h2>All Rooms</h2>

    <?php
    $conn = new mysqli("localhost", "root", "", "hostel_management");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM rooms";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Room Number</th>
                    <th>Capacity</th>
                    <th>Occupied</th>
                    <th>Action</th>
                </tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>".$row["id"]."</td>
                    <td>".$row["room_number"]."</td>
                    <td>".$row["capacity"]."</td>
                    <td>".$row["occupied"]."</td>
                    <td><a href='delete_room.php?id=".$row["id"]."' onclick=\"return confirm('Are you sure to delete this room?');\">Delete</a></td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "No rooms available.";
    }

    $conn->close();
    ?>
</body>
</html>
