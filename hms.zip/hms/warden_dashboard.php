<?php
session_start();

// Optional: Check if user is warden
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'warden') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Warden Dashboard</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background: #f2f2f2;
        }
        .header {
            background-color: #007bff;
            padding: 20px;
            color: white;
            text-align: center;
        }
        .container {
            margin: 40px auto;
            max-width: 600px;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .link-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 30px;
        }
        a.button {
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 12px;
            text-align: center;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.2s;
        }
        a.button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="header">
        <h1>Welcome Warden</h1>
    </div>

    <div class="container">
        <h2>Dashboard</h2>
        <div class="link-list">
            <a href="view_leave_requests.php" class="button">View Leave Requests</a>
            <a href="view_complaints.php" class="button"> View Complaints</a>
            <a href="view_room.php" class="button"> View Rooms</a>
            <a href="logout.php" class="button"> Logout</a>
        </div>
    </div>

</body>
</html>
