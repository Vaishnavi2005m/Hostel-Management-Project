<?php
include 'db_connect.php';

$id = $_GET['id'];
$status = $_GET['status'];

$sql = "UPDATE fees SET status='$status', paid_at=NOW() WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: view_fees.php");
    exit();
} else {
    echo "Error updating fee status: " . $conn->error;
}

$conn->close();
?>