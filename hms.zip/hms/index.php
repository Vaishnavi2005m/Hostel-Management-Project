<?php
echo "Hello,Hostel Management System!";
?>