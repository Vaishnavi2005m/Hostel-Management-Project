<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .dashboard {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
            text-align: center;
        }

        h1 {
            margin-bottom: 30px;
        }

        .button-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        a.btn {
            display: block;
            padding: 15px;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background 0.3s;
        }

        a.btn:hover {
            background: #45a049;
        }

        .logout {
            margin-top: 30px;
            display: inline-block;
            background: #f44336;
        }

        .logout:hover {
            background: #e53935;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <h1>Welcome Student 👋</h1>

    <div class="button-grid">
        <a href="room_booking.php" class="btn">Apply for Room</a>
        <a href="apply_leave.php" class="btn">Request Leave</a>
        <a href="leave_status.php" class="btn">Check Leave Status</a>
        <a href="submit_complaints.php" class="btn">Submit Complaint</a>
        <a href="pay_fee.php" class="btn">Pay Fees</a>
        <a href="leave_status.php" class="btn">View Status Updates</a>
    </div>

    <a href="logout.php" class="btn logout">Logout</a>
</div>

</body>
</html>
