<?php
include 'db_connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role  = $_POST['role'];

    // Prevent duplicate registrations
    $check = "SELECT * FROM users WHERE email='$email'";
    $check_result = $conn->query($check);

    if ($check_result->num_rows > 0) {
        echo "<p style='color:red; text-align:center;'>❌ Email already registered! <a href='login.html'>Login here</a></p>";
    } else {
        $sql = "INSERT INTO users (name, email, role) VALUES ('$name', '$email', '$role')";
        if ($conn->query($sql) === TRUE) {
            echo "<p style='color:green; text-align:center;'>✅ Registration successful! <a href='login.html'>Login here</a></p>";
        } else {
            echo "<p style='color:red; text-align:center;'>❌ Error: " . $conn->error . "</p>";
        }
    }

    $conn->close();
}
?>