<!DOCTYPE html>
<html>
<head>
    <title>View Complaints</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f7fa;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        a {
            text-decoration: none;
            padding: 6px 12px;
            background-color: #28a745;
            color: white;
            border-radius: 4px;
            font-weight: bold;
        }

        a:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

<?php
include 'db_connect.php';

$sql = "SELECT * FROM complaints ORDER BY submitted_at DESC";
$result = $conn->query($sql);

echo "<h2>All Complaints</h2>";
echo "<table>
<tr>
    <th>ID</th>
    <th>Student ID</th>
    <th>Subject</th>
    <th>Description</th>
    <th>Status</th>
    <th>Action</th>
</tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['student_id']}</td>
        <td>{$row['subject']}</td>
        <td>{$row['description']}</td>
        <td>{$row['status']}</td>
        <td>
            <a href='update_complaint_status.php?id={$row['id']}&status=Resolved'>Mark as Resolved</a>
        </td>
    </tr>";
}

$conn->close();
echo "</table>";
?>

</body>
</html>
