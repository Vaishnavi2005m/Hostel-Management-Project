<?php
include 'db_connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);

    $sql = "SELECT * FROM users WHERE name='$name' AND email='$email'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $_SESSION['name'] = $row['name'];
        $_SESSION['email'] = $row['email'];
        $_SESSION['role'] = $row['role'];

        if ($row['role'] == 'student') {
            header("Location: student_dashboard.php");
        } elseif ($row['role'] == 'warden') {
            header("Location: warden_dashboard.php");
        } elseif ($row['role'] == 'admin') {
            header("Location: admin_dashboard.php");
        } else {
            echo "❌ Unknown role!";
        }
        exit();
    } else {
        echo "<p style='color:red; text-align:center;'>❌ Invalid Name or Email!</p>";
    }
}
?>