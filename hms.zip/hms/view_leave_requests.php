<!DOCTYPE html>
<html>
<head>
    <title>Leave Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        a {
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
        }

        a[href*="Approved"] {
            background-color: #28a745;
            color: white;
        }

        a[href*="Rejected"] {
            background-color: #dc3545;
            color: white;
        }

        a:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>

<?php
include 'db_connect.php';

$result = $conn->query("SELECT * FROM leave_requests");

echo "<h2>Leave Requests</h2>";
echo "<table>
<tr>
<th>ID</th><th>Student ID</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th>Action</th>
</tr>";

while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>{$row['id']}</td>
    <td>{$row['student_id']}</td>
    <td>{$row['from_date']}</td>
    <td>{$row['to_date']}</td>
    <td>{$row['reason']}</td>
    <td>{$row['status']}</td>
    <td>
        <a href='approve_leave.php?id={$row['id']}&status=Approved'>Approve</a>
        <a href='approve_leave.php?id={$row['id']}&status=Rejected'>Reject</a>
    </td>
    </tr>";
}
echo "</table>";

$conn->close();
?>

</body>
</html>
