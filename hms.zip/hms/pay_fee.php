<!DOCTYPE html>
<html>
<head>
    <title>Pay Fee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f6fc;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            background: #fff;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input[type="number"],
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        .message {
            margin-top: 20px;
            padding: 12px;
            border-radius: 6px;
            text-align: center;
            font-weight: bold;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Pay Hostel Fee</h2>
    <form method="post">
        <label>Student ID:</label>
        <input type="number" name="student_id" required>

        <label>Amount:</label>
        <input type="text" name="amount" required>

        <input type="submit" value="Pay Fee">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include 'db_connect.php';
        include 'notification_helper.php';

        $student_id = $_POST['student_id'];
        $amount = $_POST['amount'];

        $sql = "INSERT INTO fees (student_id, amount, status, paid_at) 
                VALUES ('$student_id', '$amount', 'Paid', NOW())";

        if ($conn->query($sql) === TRUE) {
            sendNotification($conn, $student_id, "Fee payment recorded successfully.", "student");
            echo "<div class='message success'>✔ Fee payment recorded successfully!</div>";
        } else {
            echo "<div class='message error'>❌ Error: " . $conn->error . "</div>";
        }

        $conn->close();
    }
    ?>
</div>

</body>
</html>
