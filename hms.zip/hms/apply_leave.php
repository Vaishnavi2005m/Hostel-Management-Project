
<?php
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'db_connect.php';

    $student_id = $_POST['student_id'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $reason = $_POST['reason'];

    $sql = "INSERT INTO leave_requests (student_id, from_date, to_date, reason)
            VALUES ('$student_id', '$from_date', '$to_date', '$reason')";

    if ($conn->query($sql) === TRUE) {
        $message = "<p class='success'>✅ Leave request submitted successfully.</p>";
    } else {
        $message = "<p class='error'>❌ Error: " . $conn->error . "</p>";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply for Leave</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            font-weight: bold;
        }
        input[type="number"],
        input[type="date"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        textarea {
            resize: vertical;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 12px;
            border: none;
            width: 100%;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #218838;
        }
        .success {
            text-align: center;
            color: green;
            font-weight: bold;
        }
        .error {
            text-align: center;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Leave Application</h2>
        <?= $message ?>
        <form action="apply_leave.php" method="post">
            <label>Student ID:</label>
            <input type="number" name="student_id" required>

            <label>From Date:</label>
            <input type="date" name="from_date" required>

            <label>To Date:</label>
            <input type="date" name="to_date" required>

            <label>Reason:</label>
            <textarea name="reason" rows="4" required></textarea>

            <input type="submit" value="Apply">
        </form>
    </div>
</body>
</html>

