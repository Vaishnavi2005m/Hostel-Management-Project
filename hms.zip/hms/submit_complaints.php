<!DOCTYPE html>
<html>
<head>
    <title>Submit Complaint</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eef2f3;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="number"],
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 12px 25px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            display: block;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .success {
            margin-top: 20px;
            padding: 10px;
            color: green;
            font-weight: bold;
            text-align: center;
        }

        .error {
            margin-top: 20px;
            padding: 10px;
            color: red;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Submit Complaint</h2>
    <form method="post">
        <label>Student ID:</label>
        <input type="number" name="student_id" required>

        <label>Subject:</label>
        <input type="text" name="subject" required>

        <label>Description:</label>
        <textarea name="description" rows="5" required></textarea>

        <input type="submit" value="Submit Complaint">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include 'db_connect.php';

        $student_id = $_POST['student_id'];
        $subject = $_POST['subject'];
        $description = $_POST['description'];

        $sql = "INSERT INTO complaints (student_id, subject, description) 
                VALUES ('$student_id', '$subject', '$description')";

        if ($conn->query($sql) === TRUE) {
            echo "<div class='success'>✔ Complaint submitted successfully!</div>";
        } else {
            echo "<div class='error'>❌ Error: " . $conn->error . "</div>";
        }

        $conn->close();
    }
    ?>
</div>

</body>
</html>
