<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

echo "<h2>Welcome to Dashboard</h2>";
echo "Logged in as: " . $_SESSION['role'];
?>
