<?php
include 'db_connect.php';
include 'notification_helper.php';
sendNotification($conn, $student_id, "Your leave request has been approved.", "student");


$id = $_GET['id'];
$status = $_GET['status'];

$sql = "UPDATE leave_requests SET status='$status' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: view_leave_requests.php");
    exit();
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>