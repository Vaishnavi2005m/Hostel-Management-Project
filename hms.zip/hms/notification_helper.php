<?php
function sendNotification($conn, $user_id, $message, $user_type) {
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, user_type) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $message, $user_type);
    $stmt->execute();
    $stmt->close();
}
?>
