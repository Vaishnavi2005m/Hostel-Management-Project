<?php
include 'db_connect.php';

$id = $_GET['id'];
$status = $_GET['status'];

$sql = "UPDATE complaints SET status='$status' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: view_complaints.php");
    exit();
} else {
    echo "Error updating complaint status: " . $conn->error;
}

$conn->close();
?>