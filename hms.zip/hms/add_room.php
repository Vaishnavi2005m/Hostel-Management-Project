<?php
// Step 1: Connect to the database
$conn = new mysqli("localhost", "root", "", "hostel_management");

// Step 2: Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 3: Get the data from the form
$room_number = $_POST['room_number'];
$capacity = $_POST['capacity'];

// Step 4: Debug (just to make sure values are coming in)
echo "Room Number: $room_number <br>";
echo "Capacity: $capacity <br>";

// Step 5: Insert into rooms table
$sql = "INSERT INTO rooms (room_number, capacity) VALUES ('$room_number', $capacity)";

if ($conn->query($sql) === TRUE) {
    echo "Room added successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
