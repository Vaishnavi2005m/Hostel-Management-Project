<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .dashboard {
            max-width: 900px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 12px rgba(0,0,0,0.1);
            text-align: center;
        }

        h1 {
            margin-bottom: 30px;
            color: #333;
        }

        .button-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        a.btn {
            display: block;
            padding: 15px;
            background: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background 0.3s;
        }

        a.btn:hover {
            background: #0056b3;
        }

        .logout {
            margin-top: 30px;
            display: inline-block;
            background: #dc3545;
        }

        .logout:hover {
            background: #c82333;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <h1>Welcome Admin 👑</h1>

    <div class="button-grid">
        <a href="manage_room.php" class="btn"> Manage Rooms</a>
       
        <a href="view_leave_requests.php" class="btn">View Leave Requests</a>
        <a href="view_complaints.php" class="btn">Handle Complaints</a>
        <a href="view_fees.php" class="btn">Manage Fees</a>
        <!---<a href="view_reports.php" class="btn">View Reports</a>--->
    </div>

    <a href="logout.php" class="btn logout">Logout</a>
</div>

</body>
</html>
