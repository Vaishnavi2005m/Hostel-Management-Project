<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_number = $_POST['room_number'];

    // Delete room query
    $sql = "DELETE FROM rooms WHERE room_number = '$room_number'";
    
    if ($conn->query($sql) === TRUE) {
        echo "✅ Room '$room_number' deleted successfully.";
    } else {
        echo "❌ Error deleting room: " . $conn->error;
    }

    $conn->close();

    // Redirect back to view_room.php
    header("Location: view_room.php");
    exit();
}
?>
