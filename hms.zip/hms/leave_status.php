<!DOCTYPE html>
<html>
<head>
    <title>My Leave Status</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h2, h3 {
            text-align: center;
            color: #333;
        }
        form {
            text-align: center;
            margin-bottom: 30px;
        }
        input[type="number"] {
            padding: 10px;
            font-size: 16px;
            width: 200px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007BFF;
            border: none;
            border-radius: 6px;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .no-record {
            text-align: center;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Check Leave Status</h2>
        <form method="post">
            <input type="number" name="student_id" placeholder="Enter Your Student ID" required>
            <input type="submit" value="Check Status">
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            include 'db_connect.php';
            $student_id = $_POST['student_id'];

            $sql = "SELECT * FROM leave_requests WHERE student_id = $student_id ORDER BY id DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<h3>Your Leave Requests</h3>";
                echo "<table>
                    <tr><th>ID</th><th>From</th><th>To</th><th>Reason</th><th>Status</th></tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['from_date']}</td>
                        <td>{$row['to_date']}</td>
                        <td>{$row['reason']}</td>
                        <td>{$row['status']}</td>
                    </tr>";
                }

                echo "</table>";
            } else {
                echo "<p class='no-record'>❌ No leave records found.</p>";
            }

            $conn->close();
        }
        ?>
    </div>
</body>
</html>
