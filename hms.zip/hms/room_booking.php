<!-- room_booking.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Book a Room</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            background: #fff;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            font-weight: bold;
        }
        select, input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .message {
            text-align: center;
            font-weight: bold;
            color: green;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Book a Room</h2>

        <?php
        $conn = new mysqli("localhost", "root", "", "hostel_management");
        
        if ($conn->connect_error) {
            die("<p class='error'>Connection failed: " . $conn->connect_error . "</p>");
        }

        if (isset($_POST['book'])) {
            $room_id = $_POST['room_id'];

            // Update occupied count
            $update_sql = "UPDATE rooms SET occupied = occupied + 1 WHERE id = $room_id AND occupied < capacity";
            if ($conn->query($update_sql) === TRUE) {
                echo "<p class='message'>✅ Room booked successfully!</p>";
            } else {
                echo "<p class='error'>❌ Error booking room: " . $conn->error . "</p>";
            }
        }

        // Show only rooms with available capacity
        $sql = "SELECT * FROM rooms WHERE occupied < capacity";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<form method='POST' action='room_booking.php'>";
            echo "<label>Select Room:</label>";
            echo "<select name='room_id' required>";
            while ($row = $result->fetch_assoc()) {
                echo "<option value='".$row['id']."'>".$row['room_number']." (Available: ".($row['capacity'] - $row['occupied']).")</option>";
            }
            echo "</select>";
            echo "<input type='submit' name='book' value='Book Room'>";
            echo "</form>";
        } else {
            echo "<p class='error'>❌ No rooms available.</p>";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
